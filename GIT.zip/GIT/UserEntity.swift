//
//  UserEntity.swift
//  TodayBehavior
//
//  Created by Mahesh Kumar on 2/25/16.
//  Copyright © 2016 Senthil Kumar. All rights reserved.
//

import Foundation
import CoreData


class UserEntity: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
