//
//  UserEntity+CoreDataProperties.swift
//  TodayBehavior
//
//  Created by Mahesh Kumar on 2/25/16.
//  Copyright © 2016 Senthil Kumar. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension UserEntity {

    @NSManaged var full_name: String?
    @NSManaged var name: String?
    @NSManaged var default_branch: String?
    @NSManaged var language: String?

}
