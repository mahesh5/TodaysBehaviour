//
//  CalenderDetailViewController.swift
//  TodayBehavior
//
//  Created by Mahesh Kumar on 2/25/16.
//  Copyright © 2016 Senthil Kumar. All rights reserved.
//

import UIKit

class CalenderDetailViewController: UIViewController {

    @IBOutlet weak var calDetailTable: UITableView!
     var details:NSArray = []
    let appDelegate:AppDelegate = AppDelegate()

    @IBOutlet weak var networkLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "History Details"
        if  self.appDelegate.isNetworkAvailable()
        {
            networkLabel.hidden = true
            calDetailTable.hidden = false
            
        }else
        {
            networkLabel.hidden = false
            calDetailTable.hidden = true
        }
        
        // Do any additional setup after loading the view.

    }
    override func viewDidAppear(animated: Bool) {
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table Delegate methods
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerViewHeight:CGFloat! = 40.0;
        
        
        let headerView:UIView! = UIView();
        
        let sno: UILabel = UILabel();
        sno.frame = CGRect(x: 0, y: 0, width: 20, height: headerViewHeight)
        sno.text = "";
        sno.font = UIFont(name: "Avenir", size: 13)
        sno.textColor = UIColor.whiteColor();
        sno.backgroundColor = UIColor.clearColor()
        headerView.addSubview(sno);
        
        let name: UILabel = UILabel();
        name.frame = CGRect(x: 20, y: 0, width: (self.view.frame.size.width-20-50)/2, height: headerViewHeight)
        name.text = "Name";
        name.textAlignment=NSTextAlignment.Left
        name.font = UIFont(name: "Avenir", size: 17.0)
        name.textColor = UIColor.whiteColor();
        name.backgroundColor = UIColor.clearColor()
        headerView.addSubview(name);
        
        
        let color: UILabel = UILabel();
        color.frame = CGRect(x: CGRectGetMaxX(name.frame), y: 0, width: 50, height: headerViewHeight)
        color.text = "Color";
        color.textAlignment=NSTextAlignment.Left
        color.font = UIFont(name: "Avenir", size: 17.0)
        color.textColor = UIColor.whiteColor();
        color.backgroundColor = UIColor.clearColor()
        headerView.addSubview(color);
        
        
        
        let email: UILabel = UILabel();
        email.frame = CGRect(x: CGRectGetMaxX(color.frame), y: 0, width: (self.view.frame.size.width-20-50)/2, height: headerViewHeight)
        email.text = "Behavior";
        email.textAlignment=NSTextAlignment.Left
        email.font = UIFont(name: "Avenir", size: 17.0)
        email.textColor = UIColor.whiteColor();
        email.backgroundColor = UIColor.clearColor()
        headerView.addSubview(email);
        return headerView;
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40;
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.details.count;
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        
        let cell:UITableViewCell = self.calDetailTable.dequeueReusableCellWithIdentifier("cell")!
        appDelegate.stoploadingindicator()

        print(cell.subviews)
        
        //cell.textLabel?.text = self.students[indexPath.row]["name"] as? String
        
        let labelSNo:UILabel=UILabel()
        labelSNo.textColor=UIColor.darkGrayColor()
        labelSNo.textAlignment=NSTextAlignment.Center
        labelSNo.translatesAutoresizingMaskIntoConstraints=false;
        labelSNo.text="\(indexPath.row+1)"
        cell .addSubview(labelSNo)
        
        
        let labelName:UILabel=UILabel()
        labelName.textColor=UIColor.darkGrayColor()
        labelName.text=""
        labelName.translatesAutoresizingMaskIntoConstraints=false;
        labelName.text=self.details[indexPath.row]["name"] as? String
        cell .addSubview(labelName)
        
        
        let btnColor:UIButton=UIButton(type: UIButtonType.Custom)
        btnColor.backgroundColor=UIColor.greenColor()
        //btnColor.layer.cornerRadius=12
        //btnColor.clipsToBounds=true
        btnColor.tag=indexPath.row
       // btnColor.addTarget(self, action: "colorButtonPressed:", forControlEvents: UIControlEvents.TouchUpInside)
        btnColor.translatesAutoresizingMaskIntoConstraints=false;
        //btnColor.text=self.students[indexPath.row]["name"] as? String
        cell .addSubview(btnColor)
        
        switch(self.details[indexPath.row]["color"] as! String)
        {
        case  "Green":
            btnColor.backgroundColor=UIColor.greenColor()
            break
        case  "Yellow":
            btnColor.backgroundColor=UIColor.yellowColor()
            break
        case  "Red":
            btnColor.backgroundColor=UIColor.redColor()
            break
            
        default :
            break
            
        }
        
        
        let labeEmail:UILabel=UILabel()
        labeEmail.textColor=UIColor.darkGrayColor()
        labeEmail.translatesAutoresizingMaskIntoConstraints=false;
        labeEmail.text=self.details[indexPath.row]["reason"] as? String
        cell .addSubview(labeEmail)
       
        
        let constraint_H = NSLayoutConstraint.constraintsWithVisualFormat("H:|[sno(==20)]-[name]-5-[color(==50)]-5-[email(==name)]-10-|", options: NSLayoutFormatOptions(rawValue: 0), metrics: nil, views: ["cell":cell,"name":labelName,"email":labeEmail,"sno":labelSNo,"color":btnColor])
        
        cell.addConstraints(constraint_H)
        
        let constraint_V_sno = NSLayoutConstraint.constraintsWithVisualFormat("V:|[sno]|", options: NSLayoutFormatOptions(rawValue: 0), metrics: nil, views: ["cell":cell,"name":labelName,"sno":labelSNo])
        
        cell.addConstraints(constraint_V_sno)
        
        
        let constraint_V_name = NSLayoutConstraint.constraintsWithVisualFormat("V:|[name]|", options: NSLayoutFormatOptions(rawValue: 0), metrics: nil, views: ["cell":cell,"name":labelName,"email":labeEmail])
        
        cell.addConstraints(constraint_V_name)
        
        
        let constraint_V_color = NSLayoutConstraint.constraintsWithVisualFormat("V:|-10-[color(==24)]-10-|", options: NSLayoutFormatOptions(rawValue: 0), metrics: nil, views: ["cell":cell,"name":labelName,"color":btnColor])
        
        cell.addConstraints(constraint_V_color)
        
        
        let constraint_V_email = NSLayoutConstraint.constraintsWithVisualFormat("V:|[email]|", options: NSLayoutFormatOptions(rawValue: 0), metrics: nil, views: ["cell":cell,"name":labelName,"email":labeEmail])
        
        cell.addConstraints(constraint_V_email)
        
        tableView.tableFooterView=UIView()
        
        return cell
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
