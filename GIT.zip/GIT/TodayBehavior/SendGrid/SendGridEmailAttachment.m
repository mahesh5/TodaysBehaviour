//
//  SendGridEmailAttachment.m
//  Pods
//
//  Created by Juan Ant. Garrido Romero on 18/11/14.
//
//

#import "SendGridEmailAttachment.h"

@implementation SendGridEmailAttachment

@end
